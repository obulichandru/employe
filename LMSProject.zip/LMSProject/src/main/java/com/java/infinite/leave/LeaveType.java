package com.java.infinite.leave;

public enum LeaveType {
	EL
}
