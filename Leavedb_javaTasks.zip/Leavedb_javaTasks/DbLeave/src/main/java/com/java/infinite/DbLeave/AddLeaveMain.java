package com.java.infinite.DbLeave;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

public class AddLeaveMain {
	
	public static void main(String[] args) throws ParseException {
		LeaveDAO dao= new  LeaveDAO(); 
		EmployLeave leave= new EmployLeave(); 
		Scanner sc= new Scanner(System.in);
		System.out.println("enter no of leave days");
		leave.setLEAVE_NO_OF_DAYS(sc.next());
		System.out.println("Enter manager comments");
		leave.setMNGR_COMMENTS(sc.next());
		System.out.println("Enter Emp id");
		leave.setEMP_ID(sc.nextInt());
		System.out.println("enter leave start date");
		
		
		leave.setLEAVE_START_DATE(sc.next());
		System.out.println("Enter leave end date");
		leave.setLEAVE_END_DATE(sc.next());
		System.out.println("enter leave reason");
		leave.setLEAVE_REASON(sc.next()); 
		try {
			System.out.println(dao.addLeave(leave));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
