package com.java.infinite.DbLeave;

import java.sql.SQLException;



public class LeaveShowMain {
	
	public static void main(String[] args)  {
		
		LeaveDAO dao= new LeaveDAO();
		EmployLeave[] leaveList; 
		try {
			leaveList= dao.ShowLeave();
			for (EmployLeave l : leaveList) { 
				System.out.println(l);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
}
