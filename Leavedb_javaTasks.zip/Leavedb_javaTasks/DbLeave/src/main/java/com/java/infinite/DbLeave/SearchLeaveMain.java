package com.java.infinite.DbLeave;

import java.sql.SQLException;
import java.util.Scanner;

public class SearchLeaveMain {
	
	public static void main(String[] args) {
		int EMP_ID;
		System.out.println("enter EMP ID");
		Scanner sc= new Scanner(System.in);
		EMP_ID = sc.nextInt();
	     LeaveDAO dao= new LeaveDAO();
			EmployLeave leave = null;
			try {
				leave = dao.searchLeave(EMP_ID);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				System.out.println(leave);
			}
	     }
	
