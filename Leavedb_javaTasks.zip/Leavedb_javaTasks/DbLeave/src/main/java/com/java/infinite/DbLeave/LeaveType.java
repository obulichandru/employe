package com.java.infinite.DbLeave;

public enum LeaveType {
	    El
	}
