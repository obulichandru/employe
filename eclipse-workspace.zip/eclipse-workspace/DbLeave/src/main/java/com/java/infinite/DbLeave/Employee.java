package com.java.infinite.DbLeave;

import java.util.Date;

public class Employee {
		
		private int empId;
		private String empName;
		private String empEmail;
		private String empMobile;
		private Date empDoj;
		private String empDept;
		private int mgrId;
		private int leaveAvail;
		public int getEmpId() {
			return empId;
		}
		
		
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getEmpEmail() {
			return empEmail;
		}
		public void setEmpEmail(String empEmail) {
			this.empEmail = empEmail;
		}
		public String getEmpMobile() {
			return empMobile;
		}
		public void setEmpMobile(String empMobile) {
			this.empMobile = empMobile;
		}
		public Date getEmpDoj() {
			return empDoj;
		}
		public void setEmpDoj(Date empDoj) {
			this.empDoj = empDoj;
		}
		public String getEmpDept() {
			return empDept;
		}
		public void setEmpDept(String empDept) {
			this.empDept = empDept;
		}
		public int getMgrId() {
			return mgrId;
		}
		public void setMgrId(int mgrId) {
			this.mgrId = mgrId;
		}
		public int getLeaveAvail() {
			return leaveAvail;
		}
		public void setLeaveAvail(int leaveAvail) {
			this.leaveAvail = leaveAvail;
		}

	}

