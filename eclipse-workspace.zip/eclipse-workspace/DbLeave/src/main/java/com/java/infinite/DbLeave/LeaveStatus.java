package com.java.infinite.DbLeave;


public enum LeaveStatus {
     PENDING, APPROVED,DENIED
}
