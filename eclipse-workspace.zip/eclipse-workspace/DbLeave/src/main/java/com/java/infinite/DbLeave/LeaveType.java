package com.java.infinite.DbLeave;

public enum LeaveType {
	    EL
	}
