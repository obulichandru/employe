package com.java.infinite.DbLeave;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class LeaveDAO {

	Connection connection;
	PreparedStatement pst;
	
	
	public EmployLeave[] ShowLeave() throws ClassNotFoundException, SQLException {
        connection = ConnectionHelper.getConnection();
        String cmd =" select * from LEAVE_HISTORY";
        pst = connection.prepareStatement(cmd);
        ResultSet rs = pst.executeQuery();
        List<EmployLeave> list = new ArrayList<EmployLeave>();
        while(rs.next()) {
            EmployLeave leave = new EmployLeave();
            leave.setLEAVE_ID(rs.getInt("LEAVE_ID"));
			leave.setLEAVE_NO_OF_DAYS(rs.getInt("LEAVE_NO_OF_DAYS"));
			leave.setMNGR_COMMENTS(rs.getString("LEAVE_MNGR_COMMENTS"));
			leave.setEMP_ID(rs.getInt("EMP_ID"));
			leave.setLEAVE_START_DATE(rs.getDate("LEAVE_START_DATE"));
			leave.setLEAVE_END_DATE(rs.getDate("LEAVE_END_DATE"));
			leave.setLEAVE_STATUS(LeaveStatus.valueOf(rs.getString("LEAVE_STATUS")));
			leave.setLEAVE_TYPE(LeaveType.valueOf(rs.getString("LEAVE_TYPE")));
			leave.setLEAVE_REASON(rs.getString("LEAVE_REASON"));
			
			list.add(leave);
        }
        return list.toArray(new EmployLeave[list.size()]);

	}
	

	 public  EmployLeave searchLeave(int empId) throws ClassNotFoundException, SQLException {
		  connection=ConnectionHelper.getConnection(); 
		  String cmd="select * from LEAVE_HISTORY where EMP_ID=?";
		  pst= connection.prepareStatement(cmd);
		  pst.setInt(1, empId);
		  ResultSet rs=pst.executeQuery();
		  EmployLeave leave =null;
		  while(rs.next()) {
			  leave= new EmployLeave();
			  leave.setEMP_ID(leave.getEMP_ID());
			  leave.setLEAVE_NO_OF_DAYS(leave.getLEAVE_NO_OF_DAYS());
			  leave.setLEAVE_START_DATE(leave.getLEAVE_START_DATE());
			  leave.setLEAVE_END_DATE(leave.getLEAVE_END_DATE());
			  leave.setMNGR_COMMENTS(leave.getMNGR_COMMENTS());
			  leave.setLEAVE_TYPE(leave.getLEAVE_TYPE());
			  leave.setLEAVE_STATUS(leave.getLEAVE_STATUS());
		  }
		return leave;
}
	 
	 
	 public String applyLeave(EmployLeave leaveDetails) throws ClassNotFoundException, SQLException {
			
			long ms = leaveDetails.getLEAVE_END_DATE().getTime() - leaveDetails.getLEAVE_START_DATE().getTime();
		    long m = ms / (1000 * 24 * 60 * 60);
		    int days = (int) m;
		    days = days + 1;
		    leaveDetails.setLEAVE_TYPE(LeaveType.EL);
		    leaveDetails.setLEAVE_STATUS(LeaveStatus.PENDING);
		    
		  //  java.util.Date today = new java.util.Date();
		    
		//    System.out.println("NO of Days Applied: " + days);
		    
		//    long ms1 = leaveDetails.getLEAVE_END_DATE().getTime() - today.getTime();
		//    long m1 = ms1/(1000*24*60*60);
		//    int edays1 = (int)m1;
		//    edays1++;
		    
		//    long ms2 = leaveDetails.getLEAVE_END_DATE().getTime() - today.getTime();
		//    long m2 = ms2/(1000*24*60*60);
		///    int edays2 = (int)m2;
		//    edays2++;
		    Employee employee = new EmployDAO().searchEmploy(leaveDetails.getEMP_ID());
		    int leaveBalance = employee.getLeaveAvail();
		    
		    if (days < 0) {
		    	return "LeaveStartDate cannot be greater than LeaveEndDate...";
		    } else if (leaveBalance - days < 0) {
		    	return "Insufficient Leave Balance...";
		    } else if (days != leaveDetails.getLEAVE_NO_OF_DAYS()) {
		    	return "Entered Days and No.of Days are Wrong...";
		//    } else if (edays1 < 0) {
		 //   	return "Leave End Date Cannot be Yesterday's Date...";
		  //  } else if (edays2 < 0) {
		    //	return "Leave StartDate Cannot be Yesterday's Date...";
		    }
		    else {

		    	leaveDetails.setLEAVE_NO_OF_DAYS(days);
		    	connection = ConnectionHelper.getConnection();
		    	
		    	String cmd = "Insert into LEAVE_HISTORY(Emp_ID,Leave_Start_Date, "
		    			+ "Leave_End_Date,Leave_Type,Leave_Status,Leave_Reason,LEAVE_NO_OF_DAYS) "
		    			+ "VALUES(?,?,?,?,?,?,?)";
		    	pst = connection.prepareStatement(cmd);
		    	
		    	pst.setInt(1, leaveDetails.getEMP_ID());
		    	pst.setDate(2, leaveDetails.getLEAVE_START_DATE());
		    	pst.setDate(3, leaveDetails.getLEAVE_END_DATE());
		    	pst.setString(4, leaveDetails.getLEAVE_TYPE().toString());
		    	pst.setString(5, leaveDetails.getLEAVE_STATUS().toString());
		    	pst.setString(6, leaveDetails.getLEAVE_REASON());
		    	pst.setInt(7, leaveDetails.getLEAVE_NO_OF_DAYS());
		    	pst.executeUpdate();
		    	
		    	cmd = "Update Employee set EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL-? WHERE "
		    			+ " EMP_ID=?";
		    	pst = connection.prepareStatement(cmd);
		    	pst.setInt(1, days);
		    	pst.setInt(2, leaveDetails.getEMP_ID());
		    	pst.executeUpdate();
		    	return "Leave Applied Successfully...And LeaveBalance Updated...";
		    	
		    }
		    
		}
		}
	 
	
