package com.java.infinite.DbLeave;

import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

public class AddLeaveMain {
	
	
public static void main(String[] args)  {
		
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		EmployLeave leave = new EmployLeave();
		
		System.out.println("Enter EmployID: ");
		leave.setEMP_ID(sc.nextInt());
		System.out.println("Enter no of Days: ");
		leave.setLEAVE_NO_OF_DAYS(sc.nextInt());
		
		System.out.println("Enter StartDate: ");
		leave.setLEAVE_END_DATE(Date.valueOf(sc.next()));
		System.out.println("Enter Leave EndDate: ");
		leave.setLEAVE_END_DATE(Date.valueOf(sc.next()));
		System.out.println("Enter Leave Type: ");
		String levtyp = sc.next();
		if(levtyp.toUpperCase().equals("EL")) {
			leave.setLEAVE_TYPE(LeaveType.EL);
		}
		System.out.println("Enter Reason: ");
		leave.setLEAVE_REASON(sc.next());
		
		
		LeaveDAO dao = new LeaveDAO();
		
		try {
			System.out.println(dao.applyLeave(leave));
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
}	

	}


