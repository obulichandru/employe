package com.java.infinite.EmployeRealTimeDb;

public class sample {

}
