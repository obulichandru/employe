package com.java.infinite.EmployeRealTimeDb;

public enum Gender {
	MALE, FEMALE
}
