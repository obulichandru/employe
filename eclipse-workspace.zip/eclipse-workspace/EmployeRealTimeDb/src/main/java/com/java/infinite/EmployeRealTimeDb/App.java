package com.java.infinite.EmployeRealTimeDb;

public class App {

  public static void main(String[] args) {
    System.out.println("Hello World!");
  }

}
