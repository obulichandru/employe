package com.java.infinite.jdbcDemo1;

public enum Gender {
	MALE, FEMALE
}
