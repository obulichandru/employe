package com.java.infinite.AgentJdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class AgentDelete {
	
	public static void main(String[] args) {

	    int AgentID; 
	   Scanner sc= new Scanner(System.in);
	    System.out.println("enter AgentNo");
	  AgentID=sc.nextInt();
	  try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
		
		String cmd = "Delete from Agent where AgentID=?";
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam",
					"root","root");
			PreparedStatement pst = con.prepareStatement(cmd); 
			pst.setInt(1, AgentID);
			pst.executeUpdate();
			System.out.println("*********Record deleted Sucessfully********");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
