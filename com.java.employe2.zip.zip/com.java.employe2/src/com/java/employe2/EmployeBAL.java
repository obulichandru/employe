package com.java.employe2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class EmployeBAL {
	static StringBuilder sb=new StringBuilder();
	SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	public boolean validateEmployee(Employe employee) throws ParseException{
		boolean isAdded=true;
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.DATE,-1);
		String yesterday=sdf.format(cal.getTime());
		
		if(employee.getLeaveStartDate().before(sdf.parse(yesterday))){
			isAdded=false;
			sb.append("leave Start Date cannot be yesterdays date");
		}
		if(employee.getLeaveEndDate().before(sdf.parse(yesterday))){
			isAdded=false;
			sb.append("Leave End Date Cannot be Yseterdays Date");
		}
		
		Date x=employee.getLeaveStartDate();
		Date y=employee.getLeaveEndDate();
		Date thisDate=new Date();
		SimpleDateFormat dateForm=new SimpleDateFormat("yyyy-MM-dd");
		
		if(x.getDate()>y.getDate()){
			
			isAdded=false;
			sb.append("Start Date Is Invalid");
		}
		return isAdded;
		
	}
	
	public String addEmployeeBal(Employe employee)throws EmployeException, ParseException{
		if(validateEmployee(employee)==true){
			employee.setLeaveAppliedOn(new Date());
			
			return new EmployeDAO().addEmployeeDao(employee);
		}else{
			throw new EmployeException(sb.toString());
		}
		
	}
	public List<Employe> showEmployeeBal(){
		return new EmployeDAO().showemployeeDao();
	}
	
	
	public String deleteEmployeeBal(int empId){
		return new EmployeDAO().deleteEmployeeDao(empId);
	}
	public Employe searchEmployeeBal(int empId){
		return new EmployeDAO().searchEmployeeDao(empId);
	}
	public int noofDaysEmployee(Employe employee) throws ParseException {
		return new EmployeDAO().noofDaysEmployee(employee);
		
	}
	public String leaveAppliedOnBal() {
		return new EmployeDAO().leaveAppliedOnDao();
	}
	public String updateEmployeeBal(Employe employee) throws EmployeException, ParseException {
		if (validateEmployee(employee) == true) {
			return new EmployeDAO().updateEmployeeDao(employee);
		} else {
			throw new EmployeException(sb.toString());
		}
	}
}


