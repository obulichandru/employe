package com.java.employe2;

public class EmployeException extends Exception {

	public EmployeException() {
		
	}

	public EmployeException(String error) {
		super(error);
		
	}
	
	

}
