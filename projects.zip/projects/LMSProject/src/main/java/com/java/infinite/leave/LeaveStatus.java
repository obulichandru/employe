package com.java.infinite.leave;

public enum LeaveStatus {
	
	PENDING, APPROVED, DENIED
}
