package com.java.infinite.AgentJdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AgentSearch {
	
	public static void main(String[] args) {
		
		
		int AgentID;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter AgentId");
		AgentID=sc.nextInt(); 
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam",
					"root","root");
			
			String cmd = "select * from Agent where AgentID=?";
			PreparedStatement pst =  con.prepareStatement(cmd); 
			pst.setInt(1,AgentID);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				System.out.println("Agent ID  " +rs.getInt("AgentID"));
				System.out.println(" Name  " +rs.getString("name"));
				System.out.println("Gender   " +rs.getString("gender"));
				System.out.println("City  " +rs.getString("city"));
				System.out.println("MaritialStatus " +rs.getString("MaritalStatus"));
				System.out.println("premium " +rs.getString("premium")); 
				
				
			}else {
				System.out.println("*******Record not Found");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
}
	}
