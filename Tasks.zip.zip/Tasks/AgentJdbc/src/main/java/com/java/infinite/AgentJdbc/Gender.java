package com.java.infinite.AgentJdbc;


public enum Gender {
	
            MALE,FEMALE

}
